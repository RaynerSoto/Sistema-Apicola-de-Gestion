create function st_angle(line1 geometry, line2 geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT ST_Angle(St_StartPoint($1), ST_EndPoint($1), St_StartPoint($2), ST_EndPoint($2))$$;

comment on function st_angle(geometry, geometry) is 'args: line1, line2 - Returns the angle between two vectors defined by 3 or 4 points, or 2 lines.';

alter function st_angle(geometry, geometry) owner to postgres;

