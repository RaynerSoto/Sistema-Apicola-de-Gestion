create function st_scale(geometry, double precision, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.ST_Scale($1, public.ST_MakePoint($2, $3, $4))$$;

comment on function st_scale(geometry, double precision, double precision, double precision) is 'args: geomA, XFactor, YFactor, ZFactor - Scales a geometry by given factors.';

alter function st_scale(geometry, double precision, double precision, double precision) owner to postgres;

