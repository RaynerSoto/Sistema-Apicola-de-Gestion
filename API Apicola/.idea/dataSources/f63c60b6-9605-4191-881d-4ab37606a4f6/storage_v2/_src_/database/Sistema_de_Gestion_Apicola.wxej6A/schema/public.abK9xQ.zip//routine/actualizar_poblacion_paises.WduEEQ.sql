create function actualizar_poblacion_paises() returns trigger
    language plpgsql
as
$$Declare
	cantidad int := 0;
Begin 
	Select SUM(poblacion) Into cantidad
	From estados
	Inner Join paises on estados.id_pais = paises.id_pais
	Where estadosid_pais = NEW.id_pais;
	UPDATE public.paises
	SET poblacion = cantidad
	WHERE  paises.id_pais = NEW.id_pais;
	Return NEW;
End;$$;

alter function actualizar_poblacion_paises() owner to postgres;

