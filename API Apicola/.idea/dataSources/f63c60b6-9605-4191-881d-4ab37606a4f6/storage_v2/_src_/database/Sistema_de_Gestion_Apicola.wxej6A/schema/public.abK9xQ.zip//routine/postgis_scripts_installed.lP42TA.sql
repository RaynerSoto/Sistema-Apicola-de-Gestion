create function postgis_scripts_installed() returns text
    immutable
    language sql
as
$$ SELECT trim('3.4.2'::text || $rev$ 3.4.2 $rev$) AS version $$;

comment on function postgis_scripts_installed() is 'Returns version of the PostGIS scripts installed in this database.';

alter function postgis_scripts_installed() owner to postgres;

